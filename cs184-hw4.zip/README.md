Graphics homework4 git repo
